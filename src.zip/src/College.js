import { Router } from "react-router";
import { Link } from "react-router-dom";

const College = (props) => {
    return (
        <div className="col-sm-12 card text-info shadow m-4 p-2">
            <div className="card-header font-weight-bold">{props.name}</div>
            <div className="card-border">
            <div className="row">
                <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">City</h6><hr/><p className="mx-5">{props.city}</p></div>
                <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">Founded year</h6><hr/><p className="mx-5">{props.year}</p></div>
                <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">Number of students</h6><hr/><p className="mx-5">{props.students}</p></div>
            </div>
            <Link to={"college/"+props.id} >
                <input type="button" className="btn btn-primary m-4 float-right" value="Details..." />
            </Link>
            </div>
            
        </div>
    )
}

export default College;