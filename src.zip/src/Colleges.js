import College from "./College";
import collegeDetails from "./data";
const Colleges = () => {
    
    let coll = collegeDetails.map(a => a ? <College name={a.name} year={a.year} city={a.city} students={a.students} id={a.id} /> : <h4>No colleges found...!</h4>)

    return(
        <div className="container">
            <h4 className="text-info m-4">List of Colleges</h4>
        <div className="row">
        {coll}
        </div>
        
        </div>
    )
}
export default Colleges;