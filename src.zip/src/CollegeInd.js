import { Router, useParams } from "react-router";
import { Link } from "react-router-dom";
import collegeDetails from "./data";
const CollegeInd = (props) => {

    const params = useParams();
    const det = collegeDetails.filter(a => a.id === parseInt(params.id));
    console.log(det)
    return (
        <div className="container shadow mt-5 text-justify text-secondary">
        <h2 className="text-center pt-5">{det[0].name}</h2>
        <p className="text-center"><b>City:</b>&nbsp;&nbsp;{det[0].city} &nbsp;&nbsp;&nbsp;&nbsp; 
        <b>State:</b>&nbsp;&nbsp;{det[0].state} &nbsp;&nbsp;&nbsp;&nbsp;
         <b>Country:</b>&nbsp;&nbsp; {det[0].country}</p>
        <p className="text-center">Year of founded: {det[0].year}</p>
        <p className="text-center">Courses offered { det[0].courses.map(a => <li>{a}</li>)}</p>
        <p className="text-center">Number of students: {det[0].students}</p>
        <p className="text-center">
            <Link to={"/Students/"+det[0].id}> <input type="button" className="btn btn-outline-primary m-4" value="get student details" />
            </Link>
        </p>
              
            </div>
    )
}

export default CollegeInd;