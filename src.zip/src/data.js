const collegeDetails = [
    {id:1,name:"Indian Institute of Technology",year:2010,city:"Chennai",state:'TN',country:"India",students:10,courses:['B.Tech','M.Tech']},
{id:2,name:"Indian Institute of Technology",year:2010,city:"Mumbai",state:'AP',country:"India",students:15,courses:['PHD','B.Tech','M.Tech']},
{id:3,name:"National Institute",year:2010,city:"Patna",state:'UP',country:"India",students:60,courses:['B.Tech','M.Tech']},
{id:4,name:"NIT",year:2010,city:"Hyderabad",state:'TS',country:"India",students:50,courses:['B.Tech','M.Tech']},{
    id:5,name:"VIT",year:2010,city:"Banglore",state:'KS',country:"India",students:70,courses:['B.Tech','M.Tech']},
    {id:6,name:"KIT",year:2010,city:"Bopal",state:'MP',country:"India",students:20,courses:['B.Tech','M.Tech']},
    {id:7,name:"MIT",year:2010,city:"Delhi",state:'DL',country:"India",students:40,courses:['B.Tech','M.Tech']},
    {id:8,name:"Indian Institute of Technology",year:2010,city:"Chennai",state:'TN',country:"India",students:10,courses:['B.Tech','M.Tech']},
{id:9,name:"Indian Institute of Technology",year:2010,city:"Mumbai",state:'AP',country:"India",students:15,courses:['PHD','B.Tech','M.Tech']},
{id:10,name:"National Institute",year:2010,city:"Patna",state:'UP',country:"India",students:60,courses:['B.Tech','M.Tech']},
{id:11,name:"NIT",year:2010,city:"Hyderabad",state:'TS',country:"India",students:50,courses:['B.Tech','M.Tech']},{
    id:12,name:"VIT",year:2010,city:"Banglore",state:'TN',country:"India",students:70,courses:['B.Tech','M.Tech']},
    {id:13,name:"NIT",year:2010,city:"Bopal",state:'MP',country:"India",students:20,courses:['B.Tech','M.Tech']},
    {id:14,name:"MIT",year:2010,city:"Delhi",state:'DL',country:"India",students:40,courses:['B.Tech','M.Tech']},
    {id:15,name:"Indian Institute of Technology",year:2010,city:"Chennai",state:'TN',country:"India",students:10,courses:['B.Tech','M.Tech']},
{id:16,name:"Indian Institute of Technology",year:2010,city:"Mumbai",state:'AP',country:"India",students:15,courses:['PHD','B.Tech','M.Tech']},
{id:17,name:"National Institute",year:2010,city:"TN",state:'UP',country:"India",students:60,courses:['B.Tech','M.Tech']},
{id:18,name:"NIT",year:2010,city:"Hyderabad",state:'TS',country:"India",students:50,courses:['B.Tech','M.Tech']},{
    id:19,name:"VIT",year:2010,city:"Banglore",state:'KS',country:"India",students:70,courses:['B.Tech','M.Tech']},
    {id:20,name:"MIT",year:2010,city:"Bopal",state:'MP',country:"India",students:20,courses:['B.Tech','M.Tech']},
    {id:21,name:"MIT",year:2010,city:"Delhi",state:'DL',country:"India",students:40,courses:['B.Tech','M.Tech']},
    {id:1,name:"Indian Institute of Technology",RGUKT:2010,city:"Chennai",state:'TN',country:"India",students:10,courses:['B.Tech','M.Tech']},
{id:22,name:"Indian Institute of Technology",year:2010,city:"Mumbai",state:'AP',country:"India",students:15,courses:['PHD','B.Tech','M.Tech']},
{id:23,name:"National Institute",year:2010,city:"Patna",state:'TS',country:"India",students:60,courses:['B.Tech','M.Tech']},
{id:24,name:"NIT",year:2010,city:"Hyderabad",state:'TS',country:"India",students:50,courses:['B.Tech','M.Tech']},{
    id:25,name:"MIT",year:2010,city:"Banglore",state:'KS',country:"India",students:70,courses:['B.Tech','M.Tech']},
    {id:26,name:"KIT",year:2010,city:"Bopal",state:'MP',country:"India",students:20,courses:['B.Tech','M.Tech']},
    {id:27,name:"MIT",year:2010,city:"Delhi",state:'DL',country:"India",students:40,courses:['B.Tech','M.Tech']},
    {id:28,name:"Indian Institute of Technology",RGUKT:2010,city:"Chennai",state:'TN',country:"India",students:10,courses:['B.Tech','M.Tech']},
{id:29,name:"Indian Institute of Technology",year:2010,city:"Mumbai",state:'AP',country:"India",students:15,courses:['PHD','B.Tech','M.Tech']},
{id:30,name:"National Institute",year:2010,city:"Patna",state:'DL',country:"India",students:60,courses:['B.Tech','M.Tech']},
{id:31,name:"NIT",year:2010,city:"Hyderabad",state:'AP',country:"India",students:50,courses:['B.Tech','M.Tech']},{
    id:32,name:"VIT",year:2010,city:"Banglore",state:'TN',country:"India",students:70,courses:['B.Tech','M.Tech']},
    {id:33,name:"KIT",year:2010,city:"Bopal",state:'AP',country:"India",students:20,courses:['B.Tech','M.Tech']},
    {id:34,name:"MIT",year:2010,city:"Delhi",state:'TN',country:"India",students:40,courses:['B.Tech','M.Tech']},
   ]


export const studentDetails = [
    {
        id:1,
        name:"student 1",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:2,
        name:"student 2",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:3,
        name:"student 3",
        year:2020,
        collegeId:2,
        skills:["java","C++","Python"]
    },
    {
        id:4,
        name:"student 4",
        year:2020,
        collegeId:3,
        skills:["java","C++","Python"]
    },
    {
        id:5,
        name:"student 1",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:6,
        name:"student 2",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:7,
        name:"student 3",
        year:2020,
        collegeId:2,
        skills:["java","C++","Python"]
    },
    {
        id:8,
        name:"student 4",
        year:2020,
        collegeId:3,
        skills:["java","C++","Python"]
    },
    {
        id:9,
        name:"student 5",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:10,
        name:"student 6",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:11,
        name:"student 7",
        year:2020,
        collegeId:2,
        skills:["java","C++","Python"]
    },
    {
        id:12,
        name:"student 8",
        year:2020,
        collegeId:3,
        skills:["java","C++","Python"]
    },
    {
        id:13,
        name:"student 1",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:14,
        name:"student 2",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:15,
        name:"student 3",
        year:2020,
        collegeId:2,
        skills:["java","C++","Python"]
    },
    {
        id:16,
        name:"student 4",
        year:2020,
        collegeId:3,
        skills:["java","C++","Python"]
    },
    {
        id:17,
        name:"student 1",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:18,
        name:"student 2",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:19,
        name:"student 3",
        year:2020,
        collegeId:2,
        skills:["java","C++","Python"]
    },
    {
        id:20,
        name:"student 4",
        year:2020,
        collegeId:3,
        skills:["java","C++","Python"]
    },
    {
        id:21,
        name:"student 5",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:22,
        name:"student 6",
        year:2020,
        collegeId:1,
        skills:["java","C++","Python"]
    },
    {
        id:23,
        name:"student 7",
        year:2020,
        collegeId:2,
        skills:["java","C++","Python"]
    },
    {
        id:24,
        name:"student 8",
        year:2020,
        collegeId:3,
        skills:["java","C++","Python"]
    }
]                       

 export const stateAndColleges = collegeDetails.map(college => {
     return ({
         state: college.state,
         college : college.name
     })
 })    


export default collegeDetails;