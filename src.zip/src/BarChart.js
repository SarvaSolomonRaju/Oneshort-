import React from "react";
import { Link } from "react-router-dom";
import BarGroup from "./BarGroup";
import collegeDetails,{ stateAndColleges } from "./data";

export class BarChart extends React.Component {
    state = {

      data: stateAndColleges.map( college => {
          return {
              name: college.state,
              value: stateAndColleges.filter(colleger => colleger.state == college.state).length

          }
      })
    }
  
    render() {
      let barHeight = 50;
          
      let barGroups = this.state.data.map((d, i) => <Link to={"/city/"+d.name}> <g  transform={`translate(0, ${i * barHeight})`}>
                                                      <BarGroup d={d} barHeight={barHeight} />
                                                    </g></Link>)                         
      
      return <svg width="800" height="450" className="border  p-4 text-secondary shadow" >
        <g className="container">
          <text className="text-info" x="10" y="30" >Frequency | colleges and state</text>
          <g className="chart" transform="translate(100,60)">
            {barGroups}
          </g>
        </g>
      </svg>
    }
  }
  