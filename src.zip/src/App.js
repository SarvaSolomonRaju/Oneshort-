import logo from './logo.svg';
import './App.css';
import Dashboard from './Dashboard';
import { BrowserRouter, Link, Route } from 'react-router-dom';
import Colleges from './Colleges';
import College from './College';
import CollegeInd from './CollegeInd';
import CityWiseDetails from './CityWiseDetails';
import Students from './Student';
import StudentInd from './StudentInd';

function App() {
  return (
    <BrowserRouter className="text-secondary">
        <div className="container-fluid">
          
     <nav className="navbar navbar-expand-md navbar-dark p-5 text-center" style={{backgroundColor:'rgb(141, 55, 149)'}}>
     <a class="navbar-brand" href="/">CollegeHub</a>
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
       <ul className="navbar-nav">
        <li className="nav-item active"><Link to="" className="nav-link">Dashboard</Link></li>
        <li className="nav-item"><Link to="/colleges" className="nav-link">Colleges</Link></li>
       </ul></div>
     </nav>
     </div>
     
     <Route path="/college/:id" exact component={CollegeInd} />
     <Route path="/city/:id" exact component={CityWiseDetails} />
     <Route path="/" exact component={Dashboard} />
     <Route path="/:id" exact component={Colleges} /> 
     <Route path="/Students/:id" exact component={Students} /> 
     <Route path="/Student/:id" exact component={StudentInd} /> 
    </BrowserRouter>
  
  );
}

export default App;
