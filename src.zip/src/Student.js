import { useParams } from "react-router";
import { Link } from "react-router-dom";
import { studentDetails } from "./data";

const Students = (props) => {

    const params = useParams();
    const ka = studentDetails.filter(a => a.collegeId === parseInt(params.id))

    const he = ka.length > 0 ? ka.map(aa => {return (
        <div className="col-sm-12 card text-info shadow m-4 p-2">
        <div className="card-header font-weight-bold">{aa.name}</div>
        <div className="card-border">
        <div className="row">
            <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">collegeId</h6><hr/><p className="mx-5">{aa.collegeId}</p></div>
            <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">joined year</h6><hr/><p className="mx-5">{aa.year}</p></div>
            <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">Student Id</h6><hr/><p className="mx-5">{aa.id}</p></div>
        </div>
        <Link to={"/student/"+aa.id} >
            <input type="button" className="btn btn-primary m-4 float-right" value="Details..." />
        </Link>
        </div>
        </div>
    )}) : <h4>Students list is empty for this college...!</h4> 
    return (
       <>
        {he}
       </>
    )
}

export default Students;