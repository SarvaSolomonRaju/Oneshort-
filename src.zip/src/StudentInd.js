import { Router, useParams } from "react-router";
import { Link } from "react-router-dom";
import { studentDetails } from "./data";

const StudentInd = (props) => {

    const params = useParams();
    const det = studentDetails.filter(a => a.id === parseInt(params.id))
    return (
        <>
        <div className="container shadow m-5 text-justify text-dark">
        <h4 className="text-secondary pt-5 pl-5 text-center">Student details</h4><hr/>
        <h2 className="text-center">Name::&nbsp;{det[0].name}</h2>
        <p className="text-center"><b>id:</b>&nbsp;&nbsp;{det[0].id} </p>
        <p className="text-center"><b>College Id::</b>{det[0].collegeId}</p>
        <p className="text-center"><b>Skillset:</b><hr/> { det[0].skills.map(a => <li>{a}</li>)}</p>
        <p className="text-center mb-5 pb-5"><b>Course Year:</b> {det[0].year}</p>          
            </div>
            </>
    )
}

export default StudentInd;