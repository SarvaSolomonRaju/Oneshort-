import { useParams } from "react-router";
import { Link } from "react-router-dom";
import collegeDetails from "./data";
const CityWiseDetails = (props) => {

    const params = useParams();
    const collegs = collegeDetails.filter(a => a.state == params.id);

    const k = collegs.map(a => {
        return (
            <div className="col-sm-12 card text-info shadow m-4 p-2">
            <div className="card-header font-weight-bold">{a.name}</div>
            <div className="card-border">
            <div className="row">
                <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">City</h6><hr/><p className="mx-5">{a.city}</p></div>
                <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">Founded year</h6><hr/><p className="mx-5">{a.year}</p></div>
                <div className="col-sm-3"><h6 className="text-secondary mx-5 my-4">Number of students</h6><hr/><p className="mx-5">{a.students}</p></div>
            </div>
            <Link to={"/college/"+a.id} >
                <input type="button" className="btn btn-primary m-4 float-right" value="Details..." />
            </Link>
            </div>
            </div>
        )
    })

    return (
        <div className="conatainer">
            <h4 className="text-info mt-5 ml-5">List of colleges in {params.id} state :: {collegs.length}</h4>
            {k}
        </div>
    )

}

export default CityWiseDetails;