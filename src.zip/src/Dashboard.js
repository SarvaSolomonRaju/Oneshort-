import { useState } from "react";
import College from './College';
import collegeDetails from './data';
import { BarChart } from "./BarChart";
const Dashboard = (props) => {

 let [college,updateCollege] = useState(collegeDetails)

    let k = college.map((college)=> {
        return(
            <div className="col-sm-3 m-4 p-4">
                  <College />
            </div>
          
        )
    })
    return(
        <>
        <div className="container m-5 text-center">
            <div className="row">
                <div className="col-sm-3">
                </div>
                <div className="col-sm-6">
                   <h4 className="text-center text-info">State and Colleges</h4> 
                   <hr/>
                <BarChart />
                </div>
            </div>
               
                
            
       
        </div>
        </>
    )
}

export default Dashboard;